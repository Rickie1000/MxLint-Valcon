# METADATA
# scope: package
# title: Do not use calculated attributes
# description: Calculated attributes can cause performance issues.
# authors:
# - Xiwen Cheng <x@cinaq.com>
# custom:
#  category: Performance
#  rulename: AvoidCalculatedAttributes
#  severity: MEDIUM
#  rulenumber: 002_0006
#  remediation: Use a microflow to calculate the value when needed instead of using calculated attributes.
#  input: .*/DomainModels\$DomainModel\.yaml
package app.mendix.domain_model.do_not_use_calculated_attributes

import rego.v1
annotation := rego.metadata.chain()[1].annotations

default allow := false
allow if count(errors) == 0

max_virtual_attributes := 0

errors contains error if {
    not input.Entities == null
    
    entity := input.Entities[_]
    entity_name := entity.Name
    attr_count := count([attr | attr := entity.Attributes[_]; attr.Value["$Type"] == "DomainModels$CalculatedValue"])
    attr_count > max_virtual_attributes
    error := sprintf("[%v, %v, %v] There are %v Virtual Attributes in entity %v which is more than %v",
        [
            annotation.custom.severity,
            annotation.custom.category,
            annotation.custom.rulenumber,
            attr_count,
            entity_name,
            max_virtual_attributes
        ]
    )
}