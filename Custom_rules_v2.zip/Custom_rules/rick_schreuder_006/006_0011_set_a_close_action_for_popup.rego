# METADATA
# scope: package
# title: Set a close action for your pop-up
# description: A pop-up page should always have its close action set to the action of a button on the page.
# authors:
# - Rick Schreuder
# custom:
#  category: Reliability
#  rulename: SetCloseActionForPopup
#  severity: MEDIUM
#  rulenumber: 006_0011
#  remediation: Set the pop-up close action to an action button on the page.
#  input: .*Forms\$Page\.yaml

package app.mendix.pages.set_close_action_for_popup

import rego.v1

annotation := rego.metadata.chain()[1].annotations

default allow := false
allow if count(errors) == 0

page_name := object.get(input, "Name", "<unknown page>")

is_popup if {
  popup_info := object.get(input, "PopupInfo", null)
  popup_info != null
}

close_action := value if {
  popup_info := object.get(input, "PopupInfo", {})
  value := object.get(popup_info, "CloseAction", null)
} else := null

has_close_action if {
  close_action != null
  close_action != ""
}

has_close_action if {
  type_name(close_action) == "object"
  object.get(close_action, "$Type", "") != ""
}

errors contains error if {
  is_popup
  not has_close_action

  error := sprintf(
    "[%v, %v, %v] Pop-up page %v has no close action configured",
    [
      annotation.custom.severity,
      annotation.custom.category,
      annotation.custom.rulenumber,
      page_name
    ]
  )
}